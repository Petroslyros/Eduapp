package gr.aueb.cf.eduapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EduappApplicationTests {

	@Test
	void contextLoads() {
	}

}

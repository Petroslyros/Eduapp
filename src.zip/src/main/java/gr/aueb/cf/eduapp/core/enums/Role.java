package gr.aueb.cf.eduapp.core.enums;

public enum Role {
    STUDENT,
    TEACHER,
    EMPLOYEE,
    SUPER_ADMIN
}

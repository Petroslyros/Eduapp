package gr.aueb.cf.eduapp.core.enums;

public enum GenderType {
    MALE, FEMALE, OTHER
}
